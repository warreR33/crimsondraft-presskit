# Crimson Draft — Factsheet

| | |
|---|---|
| **Title** | Crimson Draft |
| **Developer** | Phase One |
| **Publisher** | Self-published |
| **Platform** | PC (Windows) |
| **Release date** | TBA |
| **Price** | TBA |
| **Genre** | Survival horror |
| **Engine** | Unity |
| **Players** | Single-player |
| **Languages** | English, Spanish |
| **itch.io** | https://phaseoneworks.itch.io/crimson-draft |
| **Press kit** | https://warrer33.github.io/crimsondraft-presskit/ |
| **Press contact** | phaseoneworks@gmail.com |
