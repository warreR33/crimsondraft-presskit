# Phase One — Studio

**Name:** Phase One
**Founded:** 2026
**Location:** Buenos Aires (CABA), Argentina
**Team size:** 5
**itch.io:** https://phaseoneworks.itch.io

## Bio (EN)
Phase One is a five-person independent team from Buenos Aires, Argentina, bringing together game design, programming, 2D and 3D art. Crimson Draft is the studio's debut project: a survival horror game rooted in the tension, scarcity and fixed-camera dread of the genre's late-90s classics.

## Bio (ES)
Phase One es un equipo independiente de cinco personas de Buenos Aires, Argentina, que reúne diseño de juego, programación y arte 2D y 3D. Crimson Draft es su primer proyecto: un survival horror que retoma la tensión, la escasez y el miedo de los clásicos del género de fines de los 90.
