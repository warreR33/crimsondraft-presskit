# Phase One Works — Team

| Name | Role | Links |
|---|---|---|
| Enrique Aebi | Game Designer | [LinkedIn](http://www.linkedin.com/in/enrique-aebi-725892166) |
| Tomás Bermúdez | 3D Artist | [LinkedIn](https://www.linkedin.com/in/tom%C3%A1s-an%C3%ADbal-berm%C3%BAdez/) · [ArtStation](https://www.artstation.com/beermu93) · [itch.io](https://beermu93.itch.io/) |
| Franco Bulgarella | Product Manager / Developer | [LinkedIn](https://www.linkedin.com/in/franco-bulgarella/) |
| David Marcano | Developer | [LinkedIn](https://www.linkedin.com/in/davidmarcano96/) · [itch.io](https://dfmr96.itch.io/) |
| Lorenzo Lodigiani | 2D Artist / Level Designer | [itch.io](https://mistsheina.itch.io/) · [Instagram](https://www.instagram.com/mistsheina/) · [Portfolio](https://warrer33.github.io/Sheina_portfolio/) |
